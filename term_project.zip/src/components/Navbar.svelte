<nav {...$$restProps}>
	<h1>Evolve Quad-Community</h1>
</nav>

<style lang="scss">
	nav {
		margin: 0 16px;
		padding: 12px 0;
		border-bottom: 1px solid #eee;
	}
</style>
