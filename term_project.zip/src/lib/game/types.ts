const types = ['Uniform asexual', 'Variable asexual', 'Sexual', 'Symbiotic']

export default types
